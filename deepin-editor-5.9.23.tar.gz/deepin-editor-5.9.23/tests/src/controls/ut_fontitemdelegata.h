#ifndef TEST_FONTITEMDELEGATA_H
#define TEST_FONTITEMDELEGATA_H


#include "gtest/gtest.h"
#include <QObject>

class test_fontitemdelegata : public QObject, public::testing::Test
{
public:
    test_fontitemdelegata();
};
#endif // TEST_FONTITEMDELEGATA_H
