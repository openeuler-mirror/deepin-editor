#ifndef TEST_SETTINGSDIALOG_H
#define TEST_SETTINGSDIALOG_H

#include "gtest/gtest.h"
#include <QObject>


class test_settingsdialog: public QObject, public::testing::Test
{
public:
    test_settingsdialog();
};

#endif // TEST_SETTINGSDIALOG_H
