#ifndef TEST_INSERTBLOCKBYTEXTCOMMOND_H
#define TEST_INSERTBLOCKBYTEXTCOMMOND_H


#include "gtest/gtest.h"
#include <QObject>
#include <QClipboard>

class test_insertblockbytextcommond: public QObject, public::testing::Test
{
        Q_OBJECT
public:
    test_insertblockbytextcommond();
};


#endif // TEST_INSERTBLOCKBYTEXTCOMMOND_H
