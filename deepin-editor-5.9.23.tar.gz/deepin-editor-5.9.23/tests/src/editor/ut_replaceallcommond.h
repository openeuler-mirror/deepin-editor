#ifndef TEST_REPLACEALLCOMMOND_H
#define TEST_REPLACEALLCOMMOND_H


#include "gtest/gtest.h"
#include <QObject>


class test_replaceallcommond: public QObject, public::testing::Test
{
        Q_OBJECT
public:
    test_replaceallcommond();
};


#endif // TEST_REPLACEALLCOMMOND_H
