//#include "test_encoding.h"

//test_encoding::test_encoding()
//{

//}

//TEST_F(test_encoding, FileLoadThread)
//{
//    extern bool validateUTF8 (const QByteArray byteArray);
//    char i = 'a';
//    QByteArray a(3,i);
//    detectCharset(a);
//    assert(1==1);
//}

//TEST_F(test_encoding, detectCharsetLatin)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detectCharsetLatin(text);
//    assert(1==1);
//}

//TEST_F(test_encoding, detectCharsetCyrillic)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detectCharsetCyrillic(text);
//    assert(1==1);
//}

//TEST_F(test_encoding, detectCharsetWinArabic)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detectCharsetWinArabic(text);
//    assert(1==1);
//}

//TEST_F(test_encoding, detectCharsetChinese)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detectCharsetChinese(text);
//    assert(1==1);
//}

//TEST_F(test_encoding, detectCharsetJapanese)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detectCharsetJapanese(text);
//    assert(1==1);
//}

//TEST_F(test_encoding, detectCharsetKorean)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detectCharsetKorean(text);
//    assert(1==1);
//}

//TEST_F(test_encoding, detect_noniso)
//{
//    const char *text = "dsfsdfsdf";
//    const std::string detect_noniso(text);
//    assert(1==1);
//}
